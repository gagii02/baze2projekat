package dao;

import model.Igrac;
import model.Osoba;

public interface OsobaDao extends CRUDDao<Osoba, Long>{
}
