package dao;

import model.Utakmica;

public interface UtakmicaDao extends CRUDDao<Utakmica, Long>{
}
