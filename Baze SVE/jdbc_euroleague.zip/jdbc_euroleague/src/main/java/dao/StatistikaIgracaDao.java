package dao;

import model.StatistikaIgraca;

public interface StatistikaIgracaDao extends CRUDDao<StatistikaIgraca, Long>{
}
