package connection;

public class ConnectionParams {
    public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";

    public static final String LOCAL_CONNECTION_STRING = "jdbc:oracle:thin:@localhost:1521:xe";

    public static final String USERNAME = "SYSTEM";
    public static final String PASSWORD = "super";
}